﻿const { Airplane } = require("./airplane.js");

it("Тестируем Airplane ", function () {
  const airplane = new Airplane();
  expect(airplane).toBeInstanceOf(Airplane);
});
it("Тестируем Airplane constitution", function () {
  // 100 - number of seats
  const airplane = new Airplane(100);

  expect(airplane.getFuel()).toEqual(0);
  expect(airplane.getNumberOfPassengers()).toEqual(0);
  expect(airplane.getNumberOfSeats()).toEqual(100);
  expect(airplane.getNumberOfPilots()).toEqual(0);
  expect(airplane.getNumberOfStewardesses()).toEqual(0);
});
