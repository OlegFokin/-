﻿class Airplane {
  constructor(numberOfSeats) {
    this.numberOfSeats = numberOfSeats;
  }
  getFuel() {
    return 0;
  }
  getNumberOfSeats() {
    return this.numberOfSeats;
  }
  getNumberOfPassengers() {
    return 0;
  }
  getNumberOfPilots() {
    return 0;
  }
  getNumberOfStewardesses() {
    return 0;
  }
}
module.exports = { Airplane };
